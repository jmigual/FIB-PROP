/**
 * This layer contains all classes that perform calculations.
 * It has a Basic package with many shared classes and other two packages to do more specific jobs.
 */
package domini;