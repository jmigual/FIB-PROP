/**
 * All KKRegions and subregions
 */
package domini.KKRegion;