/**
 * Contains basic classes to store data and players, also it includes a Players' Administration tool
 */
package dades;