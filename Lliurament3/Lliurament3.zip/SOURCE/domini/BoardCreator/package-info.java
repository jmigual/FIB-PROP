/**
 * Package to generate a new KKBoard created by the User or the CPU
 */
package domini.BoardCreator;