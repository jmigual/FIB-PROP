/**
 * Contains basic classes that can be shared with anyone
 */
package domini.Basic;